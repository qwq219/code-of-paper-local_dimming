function B = look_neighbor( lamda,T )
%Calculate the Euclidean distance between any two weight vectors
N =size(lamda,1);
B=zeros(N,T);
distance=zeros(N,N);
for i=1:N
    for j=1:N
        l=lamda(i,:)-lamda(j,:);
        distance(i,j)=sqrt(l*l'); 
    end
end
%Find the index of the nearest T weight vectors for each weight vector
for i=1:N
    [~,index]=sort(distance(i,:)); % Sort distance
    B(i,:)=index(1:T); % Select 20 close ones based on the index value of the distance
end

