% Get the grayscale image corresponding to the backlight
function Y3 = get_gray(DATA,Y,I_avg)
[m,n]=size(Y);
temp=reshape(DATA,36,66);
BL1_smooth = smoothBL_BMA(temp,m,n);
BL1_smooth(BL1_smooth < 0) = 0;
BL1_smooth(BL1_smooth > 255) = 255;
Y3 = two_stage_com2(BL1_smooth,Y,I_avg);
end