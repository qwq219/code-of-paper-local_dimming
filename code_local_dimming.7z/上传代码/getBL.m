function  BL_LUT = getBL(Y)
[m,n]=size(Y); 
%% Get backlight values
I = floor(Y);
h = floor(m / 36);           
w = floor(n / 66); 
for i = 1:35
    for j = 1:65
        x1 = 1 + h * (i - 1);
        x2 = h * i;
        y1 = 1 + w * (j - 1);
        y2 = w * j;
        C = I(x1:x2,y1:y2);  % Virtual partition of the input image
        BL_LUT(i,j) = getBL_LUT(C);

    end
end

for j = 1:65
    x1 = 35 * h + 1;
    x2 = m;
    y1 = 1 + w * (j - 1);
    y2 = w * j;
    C = I(x1:x2,y1:y2);
    BL_LUT(36,j) = getBL_LUT(C);
end

for i = 1:35
    x1 = 1 + h * (i - 1);
    x2 = h * i;
    y1 = 65 * w + 1;
    y2 = n;
    C = I(x1:x2,y1:y2);
    BL_LUT(i,66) = getBL_LUT(C);
end

x1 = 35 * h + 1;
x2 = m;
y1 = 65 * w + 1;
y2 = n;
C = I(x1:x2,y1:y2);
BL_LUT(36,66) = getBL_LUT(C);




