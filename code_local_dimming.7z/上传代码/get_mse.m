%get MSE
function [outputArg1] = get_mse(inputArg1,inputArg2)
[h,w]=size(inputArg1);
tmp=inputArg1-inputArg2;
outputArg1 = sum(sum(tmp.^2))/(h*w);
outputArg1 = outputArg1 / 10;
end

