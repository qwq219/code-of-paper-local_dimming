function [chromo_offspring,num] = cross_mutation( chromo_parent_1,chromo_parent_2,f_num,x_num,x_min,x_max,pc,pm,yita1,yita2,Y,I_avg)
%Simulate binary crossover and polynomial mutation
%binary crossover
if(rand(1)<pc)
    off_1=zeros(1,x_num+f_num+1);
    %Perform analog binary crossover
    u1=zeros(1,x_num);
    gama=zeros(1,x_num);
    for j=1:x_num
        u1(j)=rand(1);
        if u1(j)<=0.5
            gama(j)=(2*u1(j))^(1/(yita1+1));
        else
            gama(j)=(1/(2*(1-u1(j))))^(1/(yita1+1));
        end
        off_1(j)=0.5*((1-gama(j))*chromo_parent_1(j)+(1+gama(j))*chromo_parent_2(j));
        %Keep children in the domain
        if(off_1(j)>x_max(j))
            off_1(j)=x_max(j);
        elseif(off_1(j)<x_min(j))
            off_1(j)=x_min(j);
        end
    end
    %Calculate the objective function value of the individual offspring
      off_1_copy(1,1:x_num) = round(off_1(1,1:x_num));
      Y3 = get_gray(off_1_copy(1,1:x_num),Y,I_avg);
      off_1_copy(1,x_num+1) = get_mse(Y3,Y);
      off_1_copy(1,x_num+2) = get_pc(off_1_copy(1,1:x_num));
      off_1_copy(1,x_num+3) = get_cr(Y3);
end
%Polynomial mutation
if(rand(1)<pm)
    u2=zeros(1,x_num);
    delta=zeros(1,x_num);
    for j=1:x_num
        u2(j)=rand(1);
        if(u2(j)<0.5)
            delta(j)=(2*u2(j))^(1/(yita2+1))-1;
        else
            delta(j)=1-(2*(1-u2(j)))^(1/(yita2+1));
        end
        off_1(j)=off_1(j)+delta(j);
        off_1(1,1:x_num) = round(off_1(1,1:x_num));
        %Keep children in the domain
        if(off_1(j)>x_max(j))
            off_1(j)= x_max(j);
        elseif(off_1(j) < x_min(j))
            off_1(j) = x_min(j);
        end
    end
    %Calculate the objective function value of the individual offspring
      off_1_copy(1,1:x_num) = round(off_1(1,1:x_num));
      Y3 = get_gray(off_1_copy(1,1:x_num),Y,I_avg);
      off_1_copy(1,x_num+1) = get_mse(Y3,Y);
      off_1_copy(1,x_num+2) = get_pc(off_1_copy(1,1:x_num));
      off_1_copy(1,x_num+3) = get_cr(Y3);
end
chromo_offspring=off_1_copy;
end

