function X = updateNeighbor( lamda,z,X,Bi,off,x_num,f_num,Y,I_avg,x_min,x_max)
% Update neighborhood solution
flag = 0;
temp = 0;
gte_off = zeros(1,length(Bi));
gte_xi = zeros(1,length(Bi));
gte_temp = zeros(1,length(Bi));
for i=1:length(Bi)
    gte_xi(i)=tchebycheff_approach(lamda,z,X(Bi(i),(x_num+1):(x_num+f_num)),Bi(i));  % Chebyshev value of individual
    gte_off(i)=tchebycheff_approach(lamda,z,off(:,(x_num+1):(x_num+f_num)),Bi(i));   % Chebyshev value of individual offspring
end
[~,index]= min(gte_xi);
[~,index_w]= max(gte_xi);
for i = 1:length(Bi)
    if gte_off(i) <= gte_xi(i)
        X(Bi(i),:)=off;
        flag = flag + 1;
    end
end
% If the first step does not happen, proceed to the second step
% Generate a new individual based on offspring and the best individual
if(flag == 0)
    X_temp(1:2376) = off(1:2376) + rand(1,2376) .* (X(index,1:2376) - off(1,1:2376));
    X_temp(1:2376) = round(X_temp(1:2376));
    Y1 = get_gray(X_temp(1:2376),Y,I_avg);
    X_temp(2377) = get_mse(Y1,Y);
    X_temp(2378) = get_pc(X_temp(1:2376));
    X_temp(2379) = get_cr(Y1);
    for i=1:length(Bi)
    gte_temp(i) = tchebycheff_approach(lamda,z,X_temp(:,(x_num+1):(x_num+f_num)),Bi(i));
        if (gte_temp(i) <= gte_xi(i))
            X(Bi(i),:) = X_temp;
            temp = temp + 1;
        end
    end
end
% If the second step does not happen, proceed to the third step
% A solution is randomly generated and replaces the worst individual
if((temp == 0) && (flag == 0))
    X_temp = x_min + rand(1,2376) .* (x_max - x_min);
    X_temp(1:2376) = round(X_temp(1:2376));
    Y1 = get_gray(X_temp(1:2376),Y,I_avg);
    X_temp(2377) = get_mse(Y1,Y);
    X_temp(2378) = get_pc(X_temp(1:2376));
    X_temp(2379) = get_cr(Y1);
    X(index_w,:) = X_temp;
end
end

