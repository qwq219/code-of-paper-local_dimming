function chromo = initialize( N,f_num,x_num,x_min,x_max,DATA,Y,I_avg )
chromo = repmat(x_min,N,1) + rand(N,x_num).*repmat(x_max-x_min,N,1); 
[m,n] = size(Y);
for i = 1:N
    chromo(i,1:x_num) = DATA(i,:);
    temp = reshape(DATA(i,:),36,66);
    BL1_smooth = smoothBL_BMA(temp,m,n);
    BL1_smooth(BL1_smooth < 0) = 0;
    BL1_smooth(BL1_smooth > 255) = 255;
    Y3 = two_stage_com2(BL1_smooth,Y,I_avg);
    chromo(i,(x_num+1)) = get_mse(Y,Y3);
    chromo(i,(x_num+2)) = get_pc(DATA(i,:));
    chromo(i,(x_num+3)) = get_cr(Y3);
    chromo(i,(x_num+f_num+1)) = 0;  
end
