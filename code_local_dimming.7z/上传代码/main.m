clear all
close all
clc
%% ------------------------parameter settings--------------------------
format long
global x_max x_min x_num f_num lamda z
f_num = 3; % Number of objective functions
x_num = 36 * 66; % Individual dimension
rand('state',sum(100*clock));
N = 200; % population size
T = 10; % neighbor size
lamda = genrate_lamda(N,f_num); % N weight vectors uniformly distributed
max_gen = 500; % The maximum number of iterations
pc = 1; 
pm = 1; 
yita1 = 2; 
yita2 = 5;
%% ------------------------initialization--------------------------
B = look_neighbor(lamda,T);
img = imread('HH.jpg');
img1 = double(img); 
R_image = img1(:,:,1);
G_image = img1(:,:,2);
B_image = img1(:,:,3);
I_avg_f = (R_image + G_image + B_image) / 3;
[YY,U,V] = rgbToyuv(img1);
[m,n] = size(YY);  
Y = zeros(108,192);
I_avg = zeros(108,192);
for i = 1:10:m
    for j = 1:10:n
        Y((i+9)/10,(j+9)/10) = YY(i,j);
        I_avg((i+9)/10,(j+9)/10) = I_avg_f(i,j);
    end
end
BL = getBL(YY); % Get the backlight value
BL = round(BL);
BL_NEW = reshape(BL,36*66,1);
x_min = (BL_NEW - 20).';
x_max = (BL_NEW + 20).';
BL_UP = BL_NEW + 20;
BL_LP = BL_NEW - 20;
BL_LP(BL_UP > 255) = 2 * BL_NEW(BL_UP > 255) - 255;
BL_UP(BL_UP > 255) = 255;
BL_UP(BL_LP < 0) = BL_NEW(BL_LP < 0) * 2;
BL_LP(BL_LP < 0) = 0; 
R = rand(36 * 66,N);
BL_UP1 = repmat(BL_UP,1,N);
BL_LP1 = repmat(BL_LP,1,N);
DATA = round(BL_LP1 + (BL_UP1 - BL_LP1).*R);
DATAT = DATA.';
X = initialize(N,f_num,x_num,x_min,x_max,DATAT,Y,I_avg);
%%Initialize z
for i = 1:f_num
    z(i) = min(X(:, x_num + i));                                                      
end
X = deterdomination(X, N, f_num, x_num);  
% Store the non-dominated individuals in the initial population in EP
X_intialize = X;
EP = [];
for i = 1:N
    if(X(i, x_num + f_num + 1) == 1)
        EP = [X(i,:);EP];
    end
end 
X = X_intialize(:,1:2379);
EP = EP(:,1:2379);
%% ------------------------update--------------------------
for gen = 1:max_gen
    for i = 1:N
       %% Gene recombination, randomly select two sequences k, l from B(i)
        index1 = randperm(T);
        parent1 = B(i,index1(1));
        parent2 = B(i,index1(2));
        off = cross_mutation(X(parent1,:),X(parent2,:),f_num,x_num,x_min,x_max,pc,pm,yita1,yita2,Y,I_avg);
        off(1,1:2376) = round(off(1,1:2376));
        off(:,x_num+1:x_num+3) = roundn(off(:,x_num+1:x_num+3),-3);
        %% Update z
        for j = 1:f_num
            z(j) = min(z(j),off(:,x_num+j));
        end
        %% Update domain solution
        X = updateNeighbor(lamda,z,X,B(i,:),off,x_num,f_num,Y,I_avg,x_min,x_max);
        %% Update EP
        [number,~] = size(EP);
        temp = 0;
        kk = [];
        for k = 1:number
            less = 0;
            equal = 0;
            greater = 0;
            for mm = 1:f_num
                if(off(:,x_num + mm) > EP(k,x_num + mm))
                    greater = greater + 1;
                elseif(off(:,x_num + mm) == EP(k,x_num + mm))
                    equal = equal + 1;
                else
                    less = less + 1;
                end
            end
            % Remove individuals dominated by offspring individuals from EP
            if(greater == 0 && equal ~= f_num)
                kk = [k kk];
            end
            % If there is no individual dominating the offspring individual in the EP, add the offspring individual to the EP
            if(less == 0 && equal ~= f_num)
                temp = 1;
            end
        end
        if(isempty(kk) == 0)
            EP(kk,:) = [];
        end
        if(temp == 0)
            EP = [EP;off];
        end
    end
end

