%%Smoothing the backlight
function BL2 = smoothBL_BMA(BL,m,n)
K = 4;
a = 0.38;
b = 0.11;
c = 0.08;
d = 0.06; 
for k = 1:K
    [M,N] = size(BL);
    for i = 1:M
        for j = 1:N
            BL1(i + 1,j + 1) = BL(i,j);
        end
    end

    for j = 1:N
        BL1(1,j + 1) = BL(1,j);
        BL1(M + 2,j + 1) = BL(M,j);
    end

    for i = 1:M
        BL1(i + 1,1) = BL(i,1);
        BL1(i + 1,N + 2) = BL(i,N);
    end

    BL1(1,1) = BL(1,1);
    BL1(1,N + 2) = BL(1,N);
    BL1(M + 2,1) = BL(M,1);
    BL1(M + 2,N + 2) = BL(M,N);
   
    for i = 1:(M + 2)
        BL2(i,1) = BL1(i,1);
        BL2(i,N + 2) = BL1(i,N + 2); 
    end
    for j = 1:(N + 2)   
        BL2(1,j) = BL1(1,j);
        BL2(M + 2,j) = BL1(M + 2,j);
    end
    for i = 2:(M + 1)
        for j = 2:(N + 1)
            BL2(i,j) = a * BL1(i,j) + b * (BL1(i,j - 1) + BL1(i,j + 1))...
                + c * (BL1(i - 1,j) + BL1(i + 1,j)) + d * (BL1(i - 1,j - 1)...
                + BL1(i - 1,j + 1) + BL1(i + 1,j - 1) + BL1(i + 1,j + 1));
        end
    end
    BL2 = imresize(BL2,2,'bilinear');   
    BL = BL2;
end
BL2 = imresize(BL2,[m,n],'bicubic');