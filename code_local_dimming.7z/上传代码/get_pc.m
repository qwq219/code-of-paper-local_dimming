function pc = get_pc(BL)
[m, n] = size(BL);
pc = sum(sum(BL)) / (255*m*n);
pc = 100 * pc;
end