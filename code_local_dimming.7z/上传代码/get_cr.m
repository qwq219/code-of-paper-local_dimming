% Get contrast radio
function H = get_cr(Y)
Y = double(Y);
[a,b]=size(Y);
k=1;
p=0.1;
q=0.9;
X = reshape(Y,1,a*b);
k=a*b-1;
X =sort(abs(X));
t1=int32(p*k);
t2=int32(q*k);
H = (X(t1)+1)/X(t2);
H = 3000 * H;
end