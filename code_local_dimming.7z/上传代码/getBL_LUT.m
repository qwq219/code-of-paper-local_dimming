function BL = getBL_LUT(I)
Avg = mean(mean(I));
Max = max(max(I));
Diff = Max - Avg;
correction = 0.5 * (Diff + Diff^2 / 255);
BL = Avg + correction;
end


