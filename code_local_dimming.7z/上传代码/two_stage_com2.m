function Y2= two_stage_com2(BL_smoothed, Y,I_avg)
BL_full = 255;
r = 2.2;
a = 0.005;
Y1 = I_avg./(1 + exp(double(a * (BL_smoothed - Y))));
k = (double(BL_smoothed)./BL_full).^(1/r);
Y2 = Y1.*log10(1+k.*Y);
end